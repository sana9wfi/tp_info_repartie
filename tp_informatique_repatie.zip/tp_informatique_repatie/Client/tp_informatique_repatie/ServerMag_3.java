package tp_informatique_repatie;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ServerMag_3 {

    public static void main(String[] args) throws Exception {
       // StoreManager_3 mag3 = new StoreManager_3();
        Registry registry = LocateRegistry.createRegistry(1097);
        registry.bind("mag3",  new StoreManager_3());
        System.out.println("Serveur magasin 3 est prêt...");
    }
}
