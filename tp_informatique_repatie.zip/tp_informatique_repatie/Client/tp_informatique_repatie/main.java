package tp_informatique_repatie;

import java.rmi.Naming;
import java.util.Scanner;
public class main {
	
	public static void getPrice(String ingredient) throws Exception {
		try {
            Store storeMag1 = (Store) Naming.lookup("rmi://localhost:1099/mag1");
            Store storeMag2 = (Store) Naming.lookup("rmi://localhost:1098/mag2");
            Store storeMag3 = (Store) Naming.lookup("rmi://localhost:1097/mag3");
            double f1 = storeMag1.getPrice(ingredient);
            double f2 = storeMag2.getPrice(ingredient);
            double f3 = storeMag3.getPrice(ingredient);
            
            double lowestPrice = Math.min(Math.min(f1, f2), f3);
            String lowestStore;
            if (lowestPrice == f1) {
                lowestStore = "Mag1";
            } else if (lowestPrice == f2) {
                lowestStore = "Mag2";
            } else {
                lowestStore = "Mag3";
            }
            
            System.out.println("Le prix le plus bas de l’ingrédient '" + ingredient + "' est de " + lowestPrice + " DT et se trouve chez " + lowestStore + ".");
        } catch (Exception e) {
            System.err.println("Erreur : " + e.getMessage());
        }
	}

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Sélectionnez le numéro de l'ingrédient :");
        System.out.println("[1] curcuma");
        System.out.println("[2] safran");
        System.out.println("[3] sel");
        System.out.println("[4] poivre");
        System.out.println("[5] paprika");
        int choix = scanner.nextInt();

        String ingredient;
        switch (choix) {
            case 1:
                ingredient = "curcuma";
                break;
            case 2:
                ingredient = "safran";
                break;
            case 3:
                ingredient = "sel";
                break;
            case 4:
                ingredient = "poivre";
                break;
            case 5:
                ingredient = "paprika";
                break;
            default:
                System.out.println("Vérifiez le numéro de l'ingrédient !");
                scanner.close();
                return;
        }
        getPrice(ingredient);
        
    }
}
