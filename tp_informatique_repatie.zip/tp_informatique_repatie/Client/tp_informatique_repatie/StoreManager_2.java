package tp_informatique_repatie;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class StoreManager_2 extends UnicastRemoteObject implements Store{

	protected StoreManager_2() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	Ingrediant  curcuma = new Ingrediant("curcuma",1.4);
	Ingrediant  safran = new Ingrediant("safran",1.1);
	Ingrediant  sel = new Ingrediant("sel",0.6);
	Ingrediant  poivre = new Ingrediant("poivre",1.9);
	Ingrediant  paprica = new Ingrediant("paprika",2.1);

	@Override
	public double getPrice(String ingredient) throws RemoteException {
		switch(ingredient) 
		{
		case "curcuma":
			return curcuma.getPrix_i();
		case "safran":
			return safran.getPrix_i();
		case "sel":
			return sel.getPrix_i();
		case "poivre":
			return poivre.getPrix_i();
		case "paprica":
			return paprica.getPrix_i();
		}
		
		return 0;
	}

}
