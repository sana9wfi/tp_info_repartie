package tp_informatique_repatie;

public class Ingrediant {
	private String nom_i;
	private double prix_i;
	public Ingrediant() {
		super();
	}
	public Ingrediant(String nom_i, double d) {
		super();
		this.nom_i = nom_i;
		this.prix_i = d;
	}
	public String getNom_i() {
		return nom_i;
	}
	public void setNom_i(String nom_i) {
		this.nom_i = nom_i;
	}
	public double getPrix_i() {
		return prix_i;
	}
	public void setPrix_i(double prix_i) {
		this.prix_i = prix_i;
	}

}
