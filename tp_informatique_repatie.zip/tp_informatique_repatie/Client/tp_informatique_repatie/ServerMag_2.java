package tp_informatique_repatie;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ServerMag_2 {

    public static void main(String[] args) throws Exception {
       // StoreManager_2 mag2 = new StoreManager_2();
        Registry registry = LocateRegistry.createRegistry(1098);
        registry.bind("mag2",  new StoreManager_2());
        System.out.println("Serveur magasin 2 est prêt...");
    }
}
