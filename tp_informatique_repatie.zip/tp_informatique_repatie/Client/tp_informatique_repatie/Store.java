package tp_informatique_repatie;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Store extends Remote{
	public double getPrice(String ingredient)throws RemoteException;

}
