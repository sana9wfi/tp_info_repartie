package tp_informatique_repatie;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ServerMag_1 {

    public static void main(String[] args) throws Exception {
        //StoreManager_1 mag1 = new StoreManager_1();
        Registry registry = LocateRegistry.createRegistry(1099);
        registry.bind("mag1",  new StoreManager_1());
        System.out.println("Serveur magasin 1 est prêt...");
    }
}
